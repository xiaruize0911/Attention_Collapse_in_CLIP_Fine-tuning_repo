# Submission checklist

- [x] First author is a high school student at submission time.
- [x] At least one high school student author is included and identified.
- [x] `High School Student` appears in the first author's affiliation.
- [x] Paper uses an IEEE Computer Society proceedings template.
- [x] Confirm the generated PDF is no more than five pages, including references.
- [x] Author names remain visible for single-blind review.
- [ ] Confirm the first author is the primary contributor and can present in person.
- [ ] Submit through the ICDM 2026 system under the Teen Research Track by August 30, 2026 (AoE), subject to any date update.
- [ ] If accepted, arrange registration and an accompanying adult guardian for the conference.
- [ ] Recheck the conference site before submission for changes to dates or presentation format.
