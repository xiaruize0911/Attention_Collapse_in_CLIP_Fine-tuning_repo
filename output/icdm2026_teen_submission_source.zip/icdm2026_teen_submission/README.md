# ICDM 2026 Teen Research Track submission

This folder contains the five-page, single-blind IEEE conference version of the CLIP attention-drift paper.

## Build

Run `latexmk -pdf main.tex` in this folder. The paper uses the standard `IEEEtran` conference class distributed with TeX Live.

## Experiment provenance

The paper is centered on the completed matched-learning-rate study documented in `../controlled_heatmap_drift_report.md` on the repository's current remote branch. `controlled_results.csv` is the paper-facing aggregate snapshot (five runs per cell). The two figures are the corresponding controlled-study plots.

To reproduce the matrix from raw training runs:

1. Run `python run_icdm2026_experiments.py` from the repository root.
2. Run `python analyze_icdm2026_results.py --refresh-zero-shot`.

The matrix contains 80 runs: two datasets, two methods, four learning rates, and five seeds. The runner resumes safely by skipping completed histories.

`smoke_test_results.md` records fresh local Full FT and LoRA runs that exercised the repaired Apple-MPS path end to end. These deliberately shortened runs are verification only and are not mixed into the paper's results.

## Venue checks

- IEEE Computer Society proceedings format (`IEEEtran`, conference mode)
- Five pages including figures, tables, and references
- Single-blind author information retained
- First-author affiliation explicitly says `High School Student`
- Primary contributor and presenter: Ruize Xia

The call lists August 30, 2026 (AoE) as the tentative submission deadline.
